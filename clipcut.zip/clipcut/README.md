# ClipCut

Turn a long video (stream, podcast, interview) into ready-to-post vertical clips with subtitles for TikTok, Reels and YouTube Shorts.

Runs locally and for free:

1. **faster-whisper** transcribes the speech
2. **Ollama** (any local LLM) picks the most engaging moments
3. **FFmpeg** cuts, crops to 9:16 and burns in subtitles

If Ollama isn't running, ClipCut falls back to a speech-density heuristic.

## Install

```bash
pip install -r requirements.txt
# FFmpeg must be installed and on PATH: https://ffmpeg.org/download.html
# Optional, for smarter clip picking:
ollama pull llama3.1
```

## Website

```bash
uvicorn app:app
# open http://localhost:8000, upload a video, download the clips
```

## Command line

```bash
python clipcut.py my_stream.mp4
python clipcut.py podcast.mp4 -n 8 --min 25 --max 50 --whisper medium -o out
```

| Option | Default | Meaning |
|---|---|---|
| `-n`, `--clips` | 5 | number of clips |
| `--min` / `--max` | 20 / 55 | clip length in seconds |
| `--whisper` | small | Whisper model size |
| `--ollama-model` | llama3.1 | local LLM used to pick moments |
| `-o`, `--out` | clips | output folder |

Output: `clip_01.mp4`, `clip_01.srt`, ... and `clips.json` with timestamps and titles.

## Roadmap

- [ ] Web UI: upload a video, download clips
- [ ] Speaker-aware cropping (follow the face)
- [ ] Styled animated captions
- [ ] Hosted version

## License

MIT
