"""ClipCut web server. Run: uvicorn app:app  ->  http://localhost:8000"""
import re
import shutil
import threading
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

import clipcut

ROOT = Path(__file__).parent
DATA = ROOT / "jobs"
DATA.mkdir(exist_ok=True)
JOBS = {}
app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


def run_job(jid, video, n, max_len):
    job = JOBS[jid]
    out = DATA / jid / "clips"
    out.mkdir(parents=True, exist_ok=True)
    min_len = max(10, max_len * 0.4)
    try:
        job["step"] = "transcribing"
        segs = clipcut.transcribe(video, "small")
        if not segs:
            raise RuntimeError("No speech found in the video")
        job["step"] = "picking"
        cands = clipcut.llm_candidates(segs, "llama3.1", "http://localhost:11434", min_len, max_len)
        cands += clipcut.heuristic_candidates(segs, max_len)
        clips = clipcut.select_clips(segs, cands, n, min_len, max_len)
        job["step"] = "cutting"
        for i, c in enumerate(clips, 1):
            name = f"clip_{i:02d}"
            clipcut.write_srt(segs, c["start"], c["end"], out / f"{name}.srt")
            clipcut.cut_clip(video, out, name, c["start"], c["end"])
            job["clips"].append(
                {"file": f"{name}.mp4", "title": c["title"] or f"Clip {i}",
                 "start": round(c["start"]), "end": round(c["end"])}
            )
        job["step"] = "done"
    except Exception as e:
        job["step"] = "error"
        job["error"] = str(e)


@app.post("/api/jobs")
async def create_job(file: UploadFile = File(...), clips: int = Form(5), max_len: int = Form(55)):
    jid = uuid.uuid4().hex[:12]
    folder = DATA / jid
    folder.mkdir()
    video = folder / ("input" + Path(file.filename or "v.mp4").suffix[:8])
    with open(video, "wb") as f:
        shutil.copyfileobj(file.file, f)
    JOBS[jid] = {"step": "queued", "clips": [], "error": None}
    args = (jid, video, max(1, min(clips, 10)), max(15, min(max_len, 90)))
    threading.Thread(target=run_job, args=args, daemon=True).start()
    return {"id": jid}


@app.get("/api/jobs/{jid}")
def job_status(jid: str):
    if jid not in JOBS:
        raise HTTPException(404)
    return JOBS[jid]


@app.get("/api/jobs/{jid}/{name}")
def get_clip(jid: str, name: str):
    path = DATA / jid / "clips" / name
    if jid not in JOBS or not re.fullmatch(r"clip_\d\d\.mp4", name) or not path.exists():
        raise HTTPException(404)
    return FileResponse(path, media_type="video/mp4")


app.mount("/", StaticFiles(directory=ROOT / "static", html=True), name="static")
