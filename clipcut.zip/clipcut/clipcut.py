#!/usr/bin/env python3
"""ClipCut: turn a long video into vertical (9:16) clips with burned-in subtitles.

Pipeline: faster-whisper (transcript) -> Ollama LLM (best moments) -> FFmpeg (cut + subtitles).
Everything runs locally and for free. If Ollama is not running, a simple
speech-density heuristic is used instead.
"""
import argparse
import json
import subprocess
import sys
import urllib.request
from pathlib import Path


# ---------- 1. Transcription ----------

def transcribe(video, model_size):
    from faster_whisper import WhisperModel

    print(f"[1/3] Transcribing with Whisper ({model_size})...")
    model = WhisperModel(model_size, device="auto", compute_type="auto")
    segments, _ = model.transcribe(str(video), vad_filter=True)
    result = [
        {"start": s.start, "end": s.end, "text": s.text.strip()}
        for s in segments
        if s.text.strip()
    ]
    print(f"      {len(result)} segments")
    return result


# ---------- 2. Picking highlights ----------

def ask_ollama(prompt, model, host):
    body = json.dumps(
        {"model": model, "prompt": prompt, "stream": False, "format": "json"}
    ).encode()
    req = urllib.request.Request(
        f"{host}/api/generate", data=body, headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=600) as r:
        return json.loads(json.loads(r.read())["response"])


def chunk_segments(segments, max_chars=8000):
    chunk, size = [], 0
    for s in segments:
        chunk.append(s)
        size += len(s["text"]) + 16
        if size >= max_chars:
            yield chunk
            chunk, size = [], 0
    if chunk:
        yield chunk


def llm_candidates(segments, model, host, min_len, max_len):
    cands = []
    for chunk in chunk_segments(segments):
        text = "\n".join(
            f"[{s['start']:.1f}-{s['end']:.1f}] {s['text']}" for s in chunk
        )
        prompt = (
            "You are a short-video editor. From the transcript below, pick the most "
            "engaging, self-contained moments (strong hook, emotion, humor, a surprising "
            f"fact or a complete story). Each clip must be {min_len:.0f}-{max_len:.0f} seconds long. "
            'Reply ONLY with JSON: {"clips":[{"start":<sec>,"end":<sec>,'
            '"title":"<short title>","score":<1-10>}]}. Return at most 4 clips.\n\n'
            f"TRANSCRIPT:\n{text}"
        )
        try:
            data = ask_ollama(prompt, model, host)
        except Exception as e:  # Ollama not running, model missing, bad JSON...
            print(f"      Ollama unavailable ({e}); using heuristic only.")
            return []
        if not isinstance(data, dict):
            continue
        for c in data.get("clips", []):
            try:
                cands.append(
                    {
                        "start": float(c["start"]),
                        "end": float(c["end"]),
                        "title": str(c.get("title", "")),
                        "score": float(c.get("score", 5)),
                    }
                )
            except (KeyError, TypeError, ValueError):
                continue
    return cands


def heuristic_candidates(segments, max_len):
    """Windows with the densest speech. Scores stay below LLM scores (1-10)."""
    cands = []
    target = max_len * 0.8
    for i, first in enumerate(segments):
        j = i
        while j + 1 < len(segments) and segments[j]["end"] - first["start"] < target:
            j += 1
        dur = segments[j]["end"] - first["start"]
        if dur <= 0:
            continue
        words = sum(len(s["text"].split()) for s in segments[i : j + 1])
        cands.append(
            {
                "start": first["start"],
                "end": segments[j]["end"],
                "title": "",
                "score": (words / dur) / 10,
            }
        )
    return cands


def snap(segments, start, end, min_len, max_len):
    """Align a candidate to whole transcript segments and clamp its length."""
    idx = [i for i, s in enumerate(segments) if s["end"] > start and s["start"] < end]
    if not idx:
        return None
    a, b = idx[0], idx[-1]
    while b > a and segments[b]["end"] - segments[a]["start"] > max_len:
        b -= 1
    while segments[b]["end"] - segments[a]["start"] < min_len and b + 1 < len(segments):
        b += 1
        if segments[b]["end"] - segments[a]["start"] > max_len:
            b -= 1
            break
    return segments[a]["start"], segments[b]["end"]


def select_clips(segments, cands, n, min_len, max_len):
    chosen = []
    for c in sorted(cands, key=lambda x: x["score"], reverse=True):
        span = snap(segments, c["start"], c["end"], min_len, max_len)
        if not span:
            continue
        start, end = span
        if end - start < min_len * 0.5:
            continue
        if any(start < o["end"] and end > o["start"] for o in chosen):
            continue
        chosen.append({"start": start, "end": end, "title": c["title"]})
        if len(chosen) == n:
            break
    return sorted(chosen, key=lambda x: x["start"])


# ---------- 3. Cutting ----------

def srt_ts(t):
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3_600_000)
    m, ms = divmod(ms, 60_000)
    s, ms = divmod(ms, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"


def write_srt(segments, start, end, path, words_per_line=5):
    blocks, idx = [], 1
    for s in segments:
        if s["end"] <= start or s["start"] >= end:
            continue
        words = s["text"].split()
        if not words:
            continue
        t0 = max(s["start"], start) - start
        t1 = min(s["end"], end) - start
        groups = [words[i : i + words_per_line] for i in range(0, len(words), words_per_line)]
        step = (t1 - t0) / len(groups)
        for g, grp in enumerate(groups):
            blocks.append(
                f"{idx}\n{srt_ts(t0 + g * step)} --> {srt_ts(t0 + (g + 1) * step)}\n{' '.join(grp)}\n"
            )
            idx += 1
    Path(path).write_text("\n".join(blocks), encoding="utf-8")


def cut_clip(video, out_dir, name, start, end):
    # Run ffmpeg inside out_dir so the subtitles filter gets a plain relative path
    # (avoids Windows drive-letter escaping problems).
    vf = (
        "crop='min(iw,ih*9/16)':'min(ih,iw*16/9)',scale=1080:1920,"
        f"subtitles={name}.srt:force_style='Alignment=2,FontSize=12,Bold=1,Outline=2,MarginV=30'"
    )
    cmd = [
        "ffmpeg", "-y", "-loglevel", "error",
        "-ss", f"{start:.2f}", "-t", f"{end - start:.2f}", "-i", str(video),
        "-vf", vf,
        "-c:v", "libx264", "-preset", "fast", "-crf", "20",
        "-c:a", "aac", "-b:a", "160k",
        f"{name}.mp4",
    ]
    subprocess.run(cmd, cwd=out_dir, check=True)


def main():
    p = argparse.ArgumentParser(description="Turn a long video into vertical clips with subtitles.")
    p.add_argument("video", help="path to the input video")
    p.add_argument("-n", "--clips", type=int, default=5, help="number of clips (default 5)")
    p.add_argument("--min", dest="min_len", type=float, default=20, help="min clip seconds")
    p.add_argument("--max", dest="max_len", type=float, default=55, help="max clip seconds")
    p.add_argument("--whisper", default="small", help="Whisper model: tiny/base/small/medium/large-v3")
    p.add_argument("--ollama-model", default="llama3.1", help="Ollama model name")
    p.add_argument("--ollama-host", default="http://localhost:11434")
    p.add_argument("-o", "--out", default="clips", help="output folder")
    a = p.parse_args()

    video = Path(a.video).resolve()
    if not video.exists():
        sys.exit(f"File not found: {video}")
    out = Path(a.out).resolve()
    out.mkdir(parents=True, exist_ok=True)

    segments = transcribe(video, a.whisper)
    if not segments:
        sys.exit("No speech found in the video.")

    print("[2/3] Picking the best moments...")
    cands = llm_candidates(segments, a.ollama_model, a.ollama_host, a.min_len, a.max_len)
    cands += heuristic_candidates(segments, a.max_len)
    clips = select_clips(segments, cands, a.clips, a.min_len, a.max_len)

    print(f"[3/3] Cutting {len(clips)} clips...")
    meta = []
    for i, c in enumerate(clips, 1):
        name = f"clip_{i:02d}"
        write_srt(segments, c["start"], c["end"], out / f"{name}.srt")
        cut_clip(video, out, name, c["start"], c["end"])
        meta.append({"file": f"{name}.mp4", **c})
        print(f"      {name}.mp4  {c['start']:.0f}s-{c['end']:.0f}s  {c['title']}")
    (out / "clips.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Done. Clips saved to {out}")


if __name__ == "__main__":
    main()
